#include<iostream>
using namespace std;
struct LinkList {
private:
	int data;
	LinkList* Link;
public:
	LinkList(int n=0, LinkList* l=NULL) {
		data = n;
		Link = l;
	}
	~LinkList() {
		if (this) delete this;
	}
	void add(int i) {
		LinkList*p = new LinkList(i);
		if (Link) {
			LinkList*q = Link;
			this->Link = p;
			p->Link = q;
		}
		else this->Link = p;
	}
	int Data() {
		return data;
	}
	void print() {
		LinkList*p = this;
		if (p) {
			cout << p->data << "->";
			p = p->Link;
		}
		while (p) {
			cout << p->data << ends;
			p = p->Link;
		}
		cout << endl;
	}
};
int main() {
	//����ͼΪ�α���G1                                                   0
	//                                                                �u���v  
	int V[] = {0,1,2,3};//                                          1 ���ࡪ 2
	int G[][6] = { {0,1},{0,2},{0,3},{1,2},{1,3},{2,3} };//           �v���u 
	//                                                                   3
	LinkList *a= new LinkList(0), *b=new LinkList(1), *c=new LinkList(2), *d=new LinkList(3);//                                  
	LinkList* list[4];  //                                                
	list[0] = a; list[1] = b; list[2] = c; list[3] = d;
	for (int i = 0; i < 6; i++) {//�����ڽӱ�
		(*list[G[i][0]]).add(G[i][1]);
		(*list[G[i][1]]).add(G[i][0]);
	}
	for (int j = 0; j < 6; j++) {
		LinkList *p = list[j];
		p->print();
	}
	return 0;
}