#include<iostream>
#include<time.h>
#include<stdlib.h>
#define MAXK 1000000
using namespace std;
clock_t start, stop;
double duration;
int BinarySearch(int *a, int x, int n)
{
	int left = 0, right = n - 1;
	while (left <= right)
	{
		int middle = (left + right) / 2;
		if (x < a[middle])right = middle - 1;
		else
			if (x < a[middle])left = middle + 1;
			else
				return middle;
	}
	return -1;
}
int Rand(int a[], int k)//�����鸳ֵ�����ѡ��һ��Ԫ����Ϊ���Ҷ���
{
	
	if (k > 0)
		return a[rand() % k];
	else
		return 0;
}
int main()
{
	srand(unsigned(time(0)));
	for (int n = 0; n <= 100; n++)//n��ȡֵ��Χ��0-100
	{
		int a[100] = { 0 },j;
		for (j = 0; j < n; j++)
			a[j] = rand();
		start = clock();
		for (int i = 1; i <= MAXK; i++)//�������MAXK��
		{
			for(int t=0;t<j;t++)//���ҵ�ƽ��ʱ��
			BinarySearch(a, a[t], n);
		}
		stop = clock();
		duration = ((double)(stop - start)) / CLK_TCK / MAXK;
		cout.setf(ios_base::fixed, ios_base::floatfield);
		cout.precision(10);
		cout << n <<ends<< duration << endl;

	}
	return 0;
}