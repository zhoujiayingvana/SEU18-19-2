#include<iostream>
using namespace std;
class ChainNode {
	friend class Chain;
public:
	ChainNode(int element = 0, ChainNode* next = 0) {
		data = element; link = next;
	}
	~ChainNode() {
		if (this) delete this;
	}
private:
	int data;
	ChainNode *link;
};
class Chain {
private:
	ChainNode*first;
	int sum;
public:
	Chain();
	void Create2();
	void Insert(ChainNode*x, int number = 0);
	void Delete(ChainNode*x, ChainNode*y);
	int length();
};
void Chain::Insert(ChainNode*x,int number) {//����һ���ڵ�
	if (first)
		x->link = new ChainNode(number, x->link);
	else
		first = new ChainNode(number);
	sum++;
}
void Chain::Delete(ChainNode*x, ChainNode*y) {
	if (x == first)first = first -> link;
	else y->link = x->link;
	delete x;
	sum--;
}
Chain::Chain() {sum = 1;}
int Chain::length() { return sum; }//ʱ�临�Ӷ�O��1��
void Chain::Create2() {
	ChainNode*second = new ChainNode(20, 0);
	first = new ChainNode(10, second);
	first->link = second;
	sum++;
}
int main() {
	Chain A;
	A.Create2();
	cout << A.length();//����Ϊ2
	return 0;
}