#include<iostream>
using namespace std;
template<class T>
class LinkedQueue;
template<class T>
class ChainNode {
	friend class LinkedQueue<T>;
public:
	ChainNode(T element = 0, ChainNode* next = 0) {
		data = element; link = next;
	}
	void PrintNode() { cout << data << ends; }
private:
	int data;
	ChainNode *link;
};
template<class T>
class LinkedQueue {
private:
	ChainNode<T>*front;
	ChainNode<T>*rear;
public:
	LinkedQueue();
	ChainNode<T>* Front() { return front; }
	ChainNode<T>* Rear() { return rear; }
	bool IsEmpty() { return rear==0; }
	void Push(const T& e);
	void Pop();
	void Print();
};
template<class T>
LinkedQueue<T>::LinkedQueue() { rear = front = 0; }//���캯��
template<class T>
void LinkedQueue<T>::Push(const T&e) {
	if (IsEmpty())front = rear = new ChainNode<T>(e, 0);
	else {
		rear=rear->link = new ChainNode<T>(e, 0);
	}
}
template<class T>
void LinkedQueue<T>::Pop() {
	if (IsEmpty())throw"Queue is empty. Cannot delete.";
	ChainNode<T> *p = front;
	front = front->link;
	delete p;
}
template<class T>
void LinkedQueue<T>::Print() {
	if (IsEmpty()) throw"No element to print.";
	ChainNode<T> *p = front;
	for(;p!=rear->link;p=p->link)
	{
		p->PrintNode();
	}
}
int main() {
	LinkedQueue<int> A;
	A.Push(2);
	A.Push(3);
	A.Push(4);
	A.Print();
	cout << endl;
	A.Pop();
	A.Pop();
	A.Print();
	return 0;

}