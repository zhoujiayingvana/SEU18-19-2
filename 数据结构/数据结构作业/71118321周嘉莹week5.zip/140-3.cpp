#include<iostream>
#include<algorithm>
using namespace std;
class Chain;//Ԥ����
class ChainIterator;
class ChainNode {
	friend class Chain;
	friend class ChainIterator;
private:
	int data;
	ChainNode *link;
public:
	ChainNode(int element = 0, ChainNode* next = 0) {
		data = element; link = next;
	}
	~ChainNode() { if (this) delete this; cout << "��������������"; }
};
class Chain {
private:
	ChainNode *first;
	ChainNode*last;
	int sum;
public:
	friend class ChainIterator;
	Chain() { first = 0; sum = 0; last = first; }//���캯��
	void Insert(ChainNode*x, ChainNode*y);
	void Delete(ChainNode*x, ChainNode*y);
	void Delete(ChainNode*x);//���غ���ɾ��ĳ���ڵ�
	int length();
	ChainNode* First() { return first; }
	ChainNode* Last() { return last; }
	class ChainIterator {//����������
		friend class Chain;
		friend class ChainNode;
	private:
		ChainNode *current;
	public:
		ChainIterator(ChainNode* startNode = 0) { //���캯��
			current = startNode;
		}
		//ChainIterator begin() { return ChainIterator(this->First()); }
		//ChainIterator end() { return ChainIterator(ThisChain, 0); }
		int&operator *()const { return current->data; }
		int*operator->()const { return&current->data; }
		ChainIterator&operator++() { current = current->link; return*this; }
		ChainIterator operator++(int) {
			ChainIterator old(*this);
			current = current->link;
			return old;
		}
		friend ostream&operator<<(ostream& out, const ChainIterator& obj) {
			out << *obj;
			return out;
		}
		bool operator != (ChainIterator right) { return current != right.current; }
		bool operator == (ChainIterator right) { return current == right.current; }

	};
	ChainIterator Begin() { return ChainIterator(first); }
	ChainIterator End() { return ChainIterator(0); }
	void AddToArray(int a[]);

};

void Chain::Insert(ChainNode*x, ChainNode*y) {//��x�ڵ�����һ��y�ڵ�,
	if (first) {
		if (x == last) {
			last = y;
			x->link = y;
		}
		else {
			y->link = x->link;
			x->link = y;
		}
	}
	else
		first = y;
	sum++;
}
void Chain::Delete(ChainNode*x, ChainNode*y) {//ɾ��x�����y
	if (y == first)first = first->link;
	else {
		if (y == last) {
			last = x; x->link = 0;
		}
		else x->link = y->link;
	}
	sum--;
}
void Chain::Delete(ChainNode*x) {//ʱ�临�Ӷ�O��length��=O��n��
	if (x == first) {//x��ͷ���
		if (sum == 1)//ֻ��һ��Ԫ��
			first->data = 0;
		else
			first = first->link;
		sum--;
	}
	else
	{
		ChainNode*p = first;
		while (p->link != x)p = p->link;//�ҵ�x��ǰһ���ڵ�
		Delete(p, x);
	}

}
inline int Chain::length() { return sum; }//ʱ�临�Ӷ�O��1��
void Chain::AddToArray(int a[]) {//����Ŀ�꺯��
	ChainIterator j = Begin();
	for (int i = 0; j != End(); i++, j++) {
		a[i] = *j;
		cout << j << ends;
	}
}
int main() {
	ChainNode *a = new ChainNode(1);
	ChainNode *b = new ChainNode(2);
	ChainNode *c = new ChainNode(3);
	ChainNode *d = new ChainNode(4);
	Chain A;
	A.Insert(A.First(), a);
	A.Insert(a, b);
	A.Insert(b, c);
	A.Insert(c, d);
	int k[4];
	A.AddToArray(k);
	return 0;

}