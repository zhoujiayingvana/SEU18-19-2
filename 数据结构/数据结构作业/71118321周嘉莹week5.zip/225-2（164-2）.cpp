#include<iostream>
using namespace std;
class DblList;
struct DblListNode {
	friend class DblList;
private:
	int data;
	DblListNode *left, *right;
public:
	DblListNode(int d=0, DblListNode *l=0, DblListNode *r=0) {
		data = d; left = l, right = r;
	}
};
class DblList {
private:
	DblListNode *first;
public:
	DblList() {//���캯��
		first= new DblListNode(-1);
		first->left = first->right = first;
	}
	void Insert(DblListNode *p, DblListNode *x);
	void Insert(DblListNode *p);//�������������p
	void Delete(DblListNode *x);
	void Concatenate(DblList m);
	void Print();
};
void DblList::Insert(DblListNode *p, DblListNode *x) {//��x�������p
	p->left = x; p->right = x->right;
	x->right->left = p; x->right = p;
}
void DblList::Insert(DblListNode *p) {//�������������p
	first->left->right = p;
	p->right = first;
	p->left = first->left;
	first->left = p;
}
	                                                                                                                             
void DblList::Delete(DblListNode *x) {
	if (x == first) throw"Deletion of header node not permitted";
	else {
		x->left->right = x->right;
		x->right->left = x->left;
		delete x;
	}
}
void DblList::Concatenate(DblList m) {
	if (m.first->right != m.first) {//m������Ϊ��
		this->first->left->right = m.first->right;//��m�����ڶ����ڵ����*this
		m.first->right->left = this->first->left;
		m.first->left->right = this->first;//mβ�ڵ�����*this
		this->first->left = m.first->left;
		m.first->right = m.first;//m����Ϊ��
	}
}
void DblList::Print() {
	if (first->right != first) {//������Ϊ��
		DblListNode *p = first->right;
		while (p != first) {
			cout << p->data << ends;
			p = p->right;
		}
	}
}
int main() {
	DblList A, B;
	DblListNode *a=new DblListNode(1), *b=new DblListNode(2),
		*c=new DblListNode(3), *d = new DblListNode(4), *e = new DblListNode(5), 
		*f = new DblListNode(10), *g = new DblListNode(9);
	A.Insert(a); A.Insert(b); A.Insert(c); A.Insert(d);
	B.Insert(f); B.Insert(g);
	A.Concatenate(B);
	A.Print();
	//B.print();
	return 0;
}