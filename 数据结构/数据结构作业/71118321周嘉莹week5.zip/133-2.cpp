#include<iostream>
using namespace std;
class ChainNode {
	friend class Chain;
public:
	ChainNode(int element = 0, ChainNode* next = 0) {
		data = element; link = next;
	}
	~ChainNode() { if (this) delete this; }
private:
	int data;
	ChainNode *link;
};
class Chain {
private:
	ChainNode*first;
	ChainNode*last;
	int sum;
public:
	Chain();
	void Create2();
	void Insert(ChainNode*x,ChainNode*y );
	void Delete(ChainNode*x, ChainNode*y);
	void Delete(ChainNode*x);//���غ���ɾ��ĳ���ڵ�
	int length();
	ChainNode* First() { return first; }
	ChainNode* Last() { return last; }
};
Chain::Chain() { sum = 0; last = first; }//���캯��
void Chain::Insert(ChainNode*x,ChainNode*y) {//��x�ڵ�����һ��y�ڵ�,
	if(first){
		if (x == last) {
			last = y;
			x->link = y;
		}
		else {
			y->link = x->link;
			x->link = y;
		}
		}
	else
		first = y;
	sum++;
}
void Chain::Delete(ChainNode*x, ChainNode*y) {//ɾ��x�����y
	if (y == first)first = first->link;
	else {
		if (y == last) {
			last = x; x->link = 0;
		}
		else x->link = y->link;
	}
	sum--;
}
void Chain::Delete(ChainNode*x) {//ʱ�临�Ӷ�O��length��=O��n��
	if (x == first) {//x��ͷ���
		if (sum == 1)//ֻ��һ��Ԫ��
			first->data = 0;
		else
			first = first->link;
		sum--;
	}
	else
	{
		ChainNode *p = first;
		while (p->link != x)p = p->link;//�ҵ�x��ǰһ���ڵ�
		Delete(p, x);
	}
		
}

int Chain::length() { return sum; }//ʱ�临�Ӷ�O��1��
void Chain::Create2() {
	ChainNode*second = new ChainNode(20, 0);
	first = new ChainNode(10, second);
	first->link = second;
	sum=2;
	last = second;
}
int main() {
	Chain A;
	A.Create2();
	ChainNode *p = new ChainNode(2);
	ChainNode *q = new ChainNode(3);
	A.Insert(A.Last(),p);
	A.Insert(p, q);
	cout << A.length();
	A.Delete(p);
	cout << A.length();
	A.Delete(q);
	cout << A.length();
	return 0;

}