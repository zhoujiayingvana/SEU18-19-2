#include<iostream>
using namespace std;
template <class T>
class LinkList;
template <class T>
class LinkNode {
	friend class LinkList<T>;
private:
	T data;
	LinkNode<T>*link;
public:
	LinkNode(T d) {
		data = d;
		link = NULL;
	}
};
template <class T>
class LinkList {
private:
	LinkNode<T>*head;
	LinkNode<T>*last;
public:
	LinkList() {
		head = NULL;
		last = NULL;
	}
	void InsertElement(T d);
	void InsertSort();
	void Print();
	~LinkList() {
		if (head) {
			LinkNode<T>*p = head;
			while (head) {
				head = head->link;
				delete p;
				p = head;
			}
		}
	}
};
template<class T>
void LinkList<T>::InsertElement(T d) {
	LinkNode<T>*temp = new LinkNode<T>(d);
	if (head) {
		last->link = temp;
		last = temp;
	}
	else {
		head = temp;
		last = temp;
	}
}
template<class T>
void LinkList<T>::InsertSort() {
	if (head == NULL) {
		cout << "�ձ�" << endl;
		return;
	}
	if (head==last) {
		cout << "�������" << endl;
		return;
	}
	LinkNode<T>*pp = head, *p = head->link, *parent = head, *current = head;
	bool flag = false;
	while (p) {
		while (current != p) {
			if (current->data > p->data) {
				if (current == head) {
					pp->link = p->link;
					p->link = current;
					head = p;
					current = head;
					p = pp->link;
					flag = true;
				}
				else {
					pp->link = p->link;
					parent->link = p;
					p->link = current;
					current = head;
					parent = head;
					p = pp->link;
					flag = true;
				}
				break;
			}
			else {
				parent = current;
				current = current->link;
			}

		}
		if (flag==false) {
			pp = pp->link;
			p = pp->link;
			current = head;
			parent = head;
		}
		flag = false;
	}
	cout << "�������" << endl;
}
template<class T>
void LinkList<T>::Print() {
	LinkNode<T>*p = head;
	while (p) {
		cout << p->data << ends;
		p = p->link;
	}
	cout << endl;
}
int main() {
	int a[11] = { 12,2,16,30,8,28,4,10,20,6,18 };
	LinkList<int> list;
	for (int i = 0; i < 11; i++) {
		list.InsertElement(a[i]);
	}
	list.Print();
	list.InsertSort();
	list.Print();
}