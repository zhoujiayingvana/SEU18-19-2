#include<iostream>
using namespace std;
template<class T>
class Stack
{
private:
	T*stack;//�洢ջԪ�ص�����
	int top, capacity;
public:
	Stack(int stackCapacity = 10);
	bool IsEmpty();
	T& Top();//����ջ��Ԫ��
	void Push(const T& item);//��ջ
	void Pop();//ɾ��ջ��Ԫ��
	Stack<T>& DivideStack();//��һ��ջ��Ϊ2��ջ��������һ��ջ;
	void CombineStack(Stack&);//������ջ�ϲ�Ϊһ��ջ������ԭջ
	void ChangeSizeID(T*, int, int);//�ı�ջ��С
	void Print();
	void Delete();
};
template<class T>
Stack<T>::Stack(int stackCpacity) :capacity(stackCpacity)//���캯��
{
	if (capacity < 1) throw"stack capackty must be > 0";
	stack = new T[capacity];
	top = -1;
}
template<class T>
inline bool Stack<T>::IsEmpty()
{
	return top == -1;
}
template<class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty())throw"Stack is empty";
	return stack[top];
}
template<class T>
void Stack<T>::ChangeSizeID(T*stack, int a, int b)
{
	if (a < b)
	{
		T*t = new T[b];
		for (int i = 0; i < a; i++) t[i] = stack[i];
		delete[]stack;
		stack = t;
	}
}
template<class T>
void Stack<T>::Push(const T&x)
{
	if (top == capacity - 1)
	{
		ChangeSizeID(stack, capacity, 2 * capacity);
		capacity *= 2;
	}
	stack[++top] = x;
}
template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())throw"Stack is empty. Cannot delete.";
	stack[top--] = 0;
}
template<class T>
Stack<T>& Stack<T>::DivideStack()
{
	Stack<T> t;
	if (!IsEmpty())
	{
		if (top == 0) throw"Stack cannot divide.";
		else {
			int i;
			for (i = (top + 1) / 2; i <= top; i++)
			{
				t.Push(stack[i]);

			}
			int p = top;
			for (i = (p + 1) / 2; i <= p; i++)
				Pop();
			return t;
		}
	}
}
template<class T>
void Stack<T>::CombineStack(Stack<T>& b)
{
	while (!b.IsEmpty())
	{
		Push(b.Top());
		b.Pop();
	}
}
template<class T>
void Stack<T>::Print()
{
	if (!IsEmpty())
	{
		for (int i = 0; i <= top; i++)
			cout << stack[i] << ends;
	}
	cout << endl;
}
template<class T>
void Stack<T>::Delete() {
	if (stack)
		delete[]stack;
}
int main()
{
	Stack<int> A, B, C;
	for (int i = 0; i < 4; i++)//���Ժ�����
	{
		A.Push(i);
		B.Push(i);
	}
	
	A.Print();
	B.Print();
	C = A.DivideStack();
	C.Print();
	A.Print();
	A.CombineStack(B);
	A.Print();
	A.Delete();
	B.Delete();
	C.Delete();
}