#include<iostream>
#include<string>
using namespace std;
class String
{
private:
	char* s;
	int *f;
public:
	String(char* a = "");
	int Length() { return strlen(s); }
	void FaliureFunnction();
	int FastFind(String pat);
	~String() { if (f) delete[]f; }
	void Printfj();
};
String::String(char* a)
{
	s = a;
	if (Length())
		f = new int[Length()];
}
void String::FaliureFunnction()//ʧ�亯��
{
	int lengthP = Length();
	f[0] = -1;
	for (int j = 1; j < lengthP; j++)
	{
		int i = f[j - 1];
		while (*(s + j) != *(s + i + 1) && (i >= 0)) i = f[i];
		if (*(s + j) == *(s + i + 1))
			f[j] = i + 1;
		else f[j] = -1;
	}
}
int String::FastFind(String pat)//���Һ���
{
	int PosP = 0, PosS = 0;//�Ӵ���ǰ�±�
	int LengthP = pat.Length(), LengthS = Length();
	while ((PosP < LengthP) && (PosS < LengthS)) {
		if (pat.s[PosP] == s[PosS])//ƥ��
		{
			PosP++; PosS++;
		}
		else
			if (PosP == 0)//�Ӵ���һ���ַ���ƥ��
				PosS++;
			else//�Ӵ��м��ַ���ƥ��
				PosP = pat.f[PosP - 1] + 1;//��ʧЧ������һ��λ�ÿ�ʼ
	}
	if (PosP < LengthP) return -1;//δ�ҵ���PosPδ�ƶ���β��
	else return PosS - LengthP;//����ƥ��ο�ͷ��λ��
}
void String::Printfj()
{
	if (f[0])
	{
		for (int i = 0; i < Length(); i++)
			cout << f[i] << ends;
		cout << endl;
	}
}
int main()
{
	String A("aaaab"), B("ababaa"), C("abaabaabb");
	A.FaliureFunnction();
	B.FaliureFunnction();
	C.FaliureFunnction();
	cout << "aaaab" << endl;
	A.Printfj();
	cout << "ababaa" << endl;
	B.Printfj();
	cout << "abaabaabb" << endl;
	C.Printfj();
}
