#include<iostream>
using namespace std;
template<class T> class ThreadedTree;
template<class T>
class TreeNode {
	friend class ThreadedTree<T>;
private:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
	bool leftThread;
	bool rightThread;
public:
	TreeNode(T d) { data = d; leftChild = 0; rightChild = 0; }
};
template<class T>
class ThreadedTree {
private:
	TreeNode<T>*root;
public:
	ThreadedTree() {
		root = new TreeNode<T>(-1);
		root->leftChild = root->rightChild = root;
		root->leftThread = root->rightThread = false;
	}
	TreeNode<T>* InorderSucc(TreeNode<T>*p);//���������̽ڵ�
	void InsertRight(TreeNode<T>*s, TreeNode<T>*r);//����������
	void InsertLeft(TreeNode<T>*s, TreeNode<T>*r);//����������
	TreeNode<T>* Root() { return root; }
};
template<class T>
TreeNode<T>* ThreadedTree<T>::InorderSucc(TreeNode<T>*currentNode) {
	TreeNode<T>*temp = currentNode->rightChild;
	{
		if (!currentNode->rightThread)//�����������
			while (!temp->leftChild)temp = temp->leftChild;
		return temp;
	}
}
template<class T>
void ThreadedTree<T>::InsertRight(TreeNode<T>*s, TreeNode<T>*r) {//��r���뵽s��������
	r->rightChild = s->rightChild;
	r->rightThread = s->rightThread;
	r->leftChild = s;
	r->rightThread = true;
	s->rightChild = r;
	s->rightThread = false;
	if (!r->rightThread) {//s���������ǿ�
		TreeNode<T>*temp = InorderSucc(r);
		temp->leftChild = r;
	}
}
template<class T>
void ThreadedTree<T>::InsertLeft(TreeNode<T>*s, TreeNode<T>*r) {
	r->leftChild = s->leftChild;
	r->leftThread = s->leftThread;
	r->rightChild = s;
	s->leftChild = r;
	s->leftThread = false;
	r->rightThread =true;
	if (!r->leftThread) {
		TreeNode<T>*pp = r->leftChild;//ppΪǰһ���ڵ�
		TreeNode<T>*temp = InorderSucc(r->leftChild);//tempΪ��ǰ�ڵ�
		while (temp != s) {
			pp = temp;
			temp = InorderSucc(temp);
		}
		pp->rightChild = r;//pp��r��ǰ�����
	}
}
int main() {
	TreeNode<int>a(1), b(2), c(3), d(4), e(5);
	ThreadedTree<int> A; //                  ��
	A.InsertLeft(A.Root(), &a);//			root
	A.InsertLeft(&a, &d);//             a
	A.InsertRight(&a, &c);//       b        c
	A.InsertLeft(&a, &b);//      d   e
	A.InsertRight(&b, &e);
	return 0;
}