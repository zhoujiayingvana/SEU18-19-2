#include<iostream>
using namespace std;
template<class T>
class Queue {
public:
	Queue(int capacity = 10);
	bool IsEmpty();
	T& Front();
	T& Rear();
	void Push(const T& item);
	void Pop();
	~Queue();
private:
	T*queue;
	int front, rear, capacity, lastOP;//lastOPΪ0ʱΪPop��Ϊ1ʱΪPush
};
template<class T>
Queue<T>::Queue(int capacity)
{

	if (capacity < 1) throw"Queue capacity must be > 0";
	queue = new T[capacity];
	this->capacity = capacity;
	front = rear = 0;
	lastOP = 0;
}
template<class T>
 bool Queue<T>::IsEmpty(){
	if ((front == rear)&&(lastOP==0)) return 1;
	else return 0;
}

template<class T>
inline T& Queue<T>::Front() {
	if (IsEmpty()) throw"Queue is empty. No front element.";
	return queue[(front + 1) % capacity];
}
template<class T>
inline T& Queue<T>::Rear() {
	if(IsEmpty()) throw"Queue is empty. No rear element.";
	return queue[rear];
}
template<class T>
void Queue<T>::Push(const T&item) {
	if ((front == rear) &&(lastOP==1)) throw"Queue is full. Cannot push an element";
	rear = (rear + 1) % capacity;
	queue[rear] = item;
	lastOP = 1;
}
template<class T>
void Queue<T>::Pop() {
	if (IsEmpty()) throw"Queue if empty.Cannot delete.";
	front = (front + 1) % capacity;
	lastOP = 0;
}
template<class T>
Queue<T>::~Queue() { delete[]queue; }
int main()
{
	Queue<int> A(3);
	A.Push(2);
	A.Push(3);
	A.Push(4);
	//A.Push(8);���������
	cout << A.Front() << A.Rear()<<endl;
	A.Pop();
	A.Pop();
	cout << A.Rear();
	return 0;
}