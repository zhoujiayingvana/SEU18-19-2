#include<iostream>
#include<deque>
using namespace std;
int mz[10][10] = { { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
{ 1, 0, 0, 1, 0, 0, 0, 1, 0, 1 },
{ 1, 0, 0, 1, 0, 0, 0, 1, 0, 1 },
{ 1, 0, 0, 0, 0, 1, 1, 0, 0, 1 },
{ 1, 0, 1, 1, 1, 0, 0, 0, 0, 1 },
{ 1, 0, 0, 0, 1, 0, 0, 0, 0, 1 },
{ 1, 0, 1, 0, 0, 0, 1, 0, 0, 1 },
{ 1, 0, 1, 1, 1, 0, 1, 1, 0, 1 },
{ 1, 1, 0, 0, 0, 0, 0, 0, 0, 1 },
{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

struct route
{
	int x;
	int y;
	int dir;
};
typedef route RT;
RT rt;
deque<RT> st;
deque<RT> minLength, maxLength;

void findPath(int x1, int y1, int x2, int y2)
{
	rt.x = x1;
	rt.y = y1;
	rt.dir = -1;
	st.push_back(rt);

	int x, y;
	int count = 0;

	while (st.size() != 0)
	{
		x = st.back().x;
		y = st.back().y;
		if (x == x2 && y == y2)
		{
			//min
			if (minLength.size() == 0)
			{
				minLength = st;
			}
			else if (minLength.size() > st.size()) {
				minLength = st;
			}

			if (maxLength.size() == 0)
			{
				maxLength = st;
			}
			else if (maxLength.size() < st.size()) {
				maxLength = st;
			}
			count++;
			st.pop_back();
		}

		RT rt1, rt2;
		int direction;
		bool find;

		rt1 = st.back();
		direction = rt1.dir;
		find = false;
		mz[rt1.x][rt1.y] = -1;
		while (direction < 3)
		{
			direction++;
			switch (direction)
			{
			case 0:
				if (mz[rt1.x - 1][rt1.y] == 0)
				{
					st.back().dir = direction;
					rt2.x = rt1.x - 1;
					rt2.y = rt1.y;
					rt2.dir = -1;
					find = true;
				}
				break;
			case 1:
				if (mz[rt1.x][rt1.y + 1] == 0)
				{
					st.back().dir = direction;
					rt2.x = rt1.x;
					rt2.y = rt1.y + 1;
					rt2.dir = -1;
					find = true;
				}
				break;
			case 2:
				if (mz[rt1.x + 1][rt1.y] == 0)
				{
					st.back().dir = direction;
					rt2.x = rt1.x + 1;
					rt2.y = rt1.y;
					rt2.dir = -1;
					find = true;
				}
				break;
			case 3:
				if (mz[rt1.x][rt1.y - 1] == 0)
				{
					st.back().dir = direction;
					rt2.x = rt1.x;
					rt2.y = rt1.y - 1;
					rt2.dir = -1;
					find = true;
				}
				break;
			}

			if (find)
			{
				break;
			}
		}

		if (find)
		{
			st.push_back(rt2);
		}
		else if (st.size() != 0)
		{
			mz[st.back().x][st.back().y] = 0;
			st.pop_back();
		}

	}

	cout << "��С��·������Ϊ: " << minLength.size()<< endl;
	RT rt1;
	int i = 0;
	while (minLength.size() != 1)
	{
		rt1 = minLength.front();
		i++;
		cout << "( " << rt1.x << ", " << rt1.y << ")" << " -> ";
		minLength.pop_front();
		if (i % 5 == 0)
		{
			i = 0;
			cout << endl;
		}
	}
	rt1 = minLength.front();
	cout << "( " << rt1.x << ", " << rt1.y << ")";
	minLength.pop_front();
	cout << endl;

	cout << "����·������Ϊ: " << maxLength.size() << "" << endl;
	i = 0;
	while (maxLength.size() != 1)
	{
		rt1 = maxLength.front();
		i++;
		cout << "( " << rt1.x << ", " << rt1.y << ")" << " -> ";
		maxLength.pop_front();
		if (i % 5 == 0)
		{
			i = 0;
			std::cout << endl;
		}
	}
	rt1 = maxLength.front();
	cout << "( " << rt1.x << ", " << rt1.y << ")";
	maxLength.pop_front();
	cout << endl;

}
int main(int argc, char** argv)
{
	void findPath(int x1, int y1, int x2, int y2);
	findPath(1, 1, 8, 8);
	return 0;
}