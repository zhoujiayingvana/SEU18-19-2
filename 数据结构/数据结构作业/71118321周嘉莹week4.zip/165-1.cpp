#include<iostream>
using namespace std;
template<class T>
class Stack
{
private:
	T*stack;//�洢ջԪ�ص�����
	int top, capacity;
public:
	Stack(int stackCapacity = 10);
	bool IsEmpty();
	T& Top();//����ջ��Ԫ��
	void Push(const T& item);//��ջ
	void Pop();//ɾ��ջ��Ԫ��
	void ChangeSizeID(T*, int, int);//�ı�ջ��С
	void Print();
	void Delete();
};
template<class T>
Stack<T>::Stack(int stackCpacity) :capacity(stackCpacity)//���캯��
{
	if (capacity < 1) throw"stack capackty must be > 0";
	stack = new T[capacity];
	top = -1;
}
template<class T>
inline bool Stack<T>::IsEmpty()
{
	return top == -1;
}
template<class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty())throw"Stack is empty";
	return stack[top];
}
template<class T>
void Stack<T>::ChangeSizeID(T*stack, int a, int b)
{
	if (a < b)
	{
		T*t = new T[b];
		for (int i = 0; i < a; i++) t[i] = stack[i];
		delete[]stack;
		stack = t;
	}
}
template<class T>
void Stack<T>::Push(const T&x)
{
	if (top == capacity - 1)
	{
		ChangeSizeID(stack, capacity, 2 * capacity);
		capacity *= 2;
	}
	stack[++top] = x;
}
template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())throw"Stack is empty. Cannot delete.";
	stack[top--] = 0;
}
template<class T>
void Stack<T>::Print()
{
	if (!IsEmpty())
	{
		for (int i = 0; i <= top; i++)
			cout << stack[i] << ends;
	}
	cout << endl;
}
template<class T>
void Stack<T>::Delete() {
	if (stack)
		delete[]stack;
}
int isp(char x) {//ջ�����ȼ�
	switch (x) {
	case'#':return 0; break;
	case'(':return 1; break;
	case'*':
	case'/':
	case'%':return 5; break;
	case'+':
	case'-':return 3; break;
	case')':return 6; break;
	default:return 0;
	}
}
int icp(char y) {//ջ�����ȼ�
	switch (y) {
	case'#':return 0; break;
	case'(':return 6; break;
	case'*':
	case'/':
	case'%':return 5; break;
	case'+':
	case'-':return 3; break;
	case')':return 1; break;
	default:return 0;
	}
}
void Postfix(char* a) {
	Stack<char>stack(20);
	stack.Push('#');
	int i;
	for (i = 0; a[i]; i++) {
		if (a[i] >= 'A'&&a[i] <= 'Z') cout << a[i];//������
		else
			if (a[i] == ')') {//��������ǰ�洢��Ĳ�����ȫ�����
				for (; stack.Top() != '('; stack.Pop())
					cout << stack.Top();
				stack.Pop();
			}
			else {//������
				for(;isp(stack.Top())>=icp(a[i]);stack.Pop())//ջ�����ȼ�����ջ��Ĳ�����
					cout << stack.Top();
					stack.Push(a[i]);//ջ��Ԫ����ջ
				}
	}
	for (; stack.Top() != '#'; stack.Pop())cout << stack.Top();
	cout << endl;
}
int main() {
	char A[] = "A*B*C", B[] = "-A+B-C+D", C[] = "A*(-B)+C", D[] = "(A+B)*D+E/(F+A*D)+C";
	Postfix(A);
	Postfix(B);
	Postfix(C);
	Postfix(D);
}