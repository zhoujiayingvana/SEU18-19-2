#include<iostream>
using namespace std;
template<class T> class Tree;
template <class T>
class Stack
{
private:
	T*stack;//�洢ջԪ�ص�����
	int top, capacity;
public:
	Stack(int stackCapacity = 10);
	bool IsEmpty();
	T& Top();//����ջ��Ԫ��
	void Push(const T& item);//��ջ
	void Pop();//ɾ��ջ��Ԫ��
};
template<class T>
Stack<T>::Stack(int stackCpacity = 20) :capacity(stackCpacity)//���캯��
{
	if (capacity < 1) throw"stack capackty must be > 0";
	stack = new T[capacity];
	top = -1;
}
template<class T>
inline bool Stack<T>::IsEmpty()
{
	return top == -1;
}
template<class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty())throw"Stack is empty";
	return stack[top];
}
template<class T>
void Stack<T>::Push(const T&x)
{
	stack[++top] = x;
}
template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())throw"Stack is empty. Cannot delete.";
	if (stack[top - 1]->leftChild == stack[top]) {
		stack[top - 1]->leftChild = 0;
	}
	else stack[top - 1]->rightChild = 0;
	top--;
}
template<class T> 
class TreeNode {//���ڵ�
	friend class tree;
public:
	T data;
	bool time;//�Ƿ��Ѿ�������
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
	TreeNode(T d=0 , bool t = false) { data = d; time = t; leftChild = 0; rightChild = 0; }
	TreeNode& operator=(TreeNode *k) {
		this->data = k->data;
		this->leftChild = k->leftChild;
		this->rightChild = k->rightChild;
		return *this;
	}
};
template<class T>
class Tree {
	friend class TreeNode<T>;
private:
	TreeNode<T>*root;
public:
	Tree(TreeNode<T> *r = 0) { root = r; }
	bool IsEmpty() { return root == 0; }
	void Insert(TreeNode<T>*p,char k='l',TreeNode<T>*x=0);//��x�������һ��p�ڵ�,k��������
	void Preorder();
	void Visit(TreeNode<T>*Node) { cout << Node->data << ends; }
};
template<class T>
void Tree<T>::Insert(TreeNode<T>*p, char k, TreeNode<T>*x) {
	if (root == 0)root = p;
	else if (k == 'l') {
		if (x->leftChild == 0)x->leftChild = p;
		else cout << "�����ӽڵ㣬���ɲ���" << endl;
	}
	else if (k == 'r') {
		if (x->rightChild == 0)x->rightChild = p;
		else cout << "�����ӽڵ㣬���ɲ���" << endl;
	}
	else cout << "����Ĳ�����/�ҽڵ�λ�ã����ɲ���"<<endl;
}
template<class T>
void Tree<T>::Preorder() {
	Stack<TreeNode<T>*>s;
	TreeNode<T>*currentNode = root;
	while (1) {
		while (currentNode) {
			s.Push(currentNode);
			currentNode = currentNode->leftChild;
		}
		if (s.IsEmpty())return;
		currentNode = s.Top();
				if (currentNode->time) {//����Ѿ������ʹ�һ��
					Visit(currentNode);
					s.Pop();
				}
				else {
					currentNode->time = true;
				}
			
		currentNode = currentNode->rightChild;
	}
}
int main() {
	TreeNode<char>*a = new TreeNode<char>('A'), *b = new TreeNode<char>('B'),
		*c = new TreeNode<char>('C'), *d = new TreeNode<char>('D'),
		*e = new TreeNode<char>('E');//����������
	Tree<char> tree;//		   a
	tree.Insert(a);//    b             c
	tree.Insert(b, 'l',a);//d       e
	tree.Insert(c, 'r', a);
	tree.Insert(d, 'r', b);
	tree.Insert(e, 'l', c);
	tree.Preorder();
	return 0;
}