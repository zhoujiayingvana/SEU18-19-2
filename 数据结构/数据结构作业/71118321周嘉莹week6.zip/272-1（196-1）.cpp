#include<iostream>
using namespace std;
template<class T> class Tree;
template<class T>
class TreeNode {//���ڵ�
	friend class tree;
public:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
	TreeNode(T d = 0) { data = d;leftChild = 0; rightChild = 0; }
	TreeNode& operator=(TreeNode *k) {
		this->data = k->data;
		this->leftChild = k->leftChild;
		this->rightChild = k->rightChild;
		return *this;
	}
};
template<class T>
class Tree {
	friend class TreeNode<T>;
private:
	TreeNode<T>*root;
	int count;
public:
	Tree(TreeNode<T> *r = 0) { root = r; count = 0; }
	bool IsEmpty() { return root == 0; }
	void Insert(TreeNode<T>*p, char k = 'l', TreeNode<T>*x = 0);//��x�������һ��p�ڵ�,k��������
	void CountNode() { CountNode(root); }
	void CountNode(TreeNode<T>*currentNode);
	void Visit(TreeNode<T>*Node) { cout << Node->data << ends; }
	int Count() { return count; }
};
template<class T>
void Tree<T>::Insert(TreeNode<T>*p, char k, TreeNode<T>*x) {
	if (root == 0)root = p;
	else if (k == 'l') {
		if (x->leftChild == 0)x->leftChild = p;
		else cout << "�����ӽڵ㣬���ɲ���" << endl;
	}
	else if (k == 'r') {
		if (x->rightChild == 0)x->rightChild = p;
		else cout << "�����ӽڵ㣬���ɲ���" << endl;
	}
	else cout << "����Ĳ�����/�ҽڵ�λ�ã����ɲ���" << endl;
}
template<class T>
void Tree<T>::CountNode(TreeNode<T>*currentNode) {
	if (currentNode) {
		if (!(currentNode->leftChild&&currentNode->rightChild))count++;
		else {
			CountNode(currentNode->leftChild);
			CountNode(currentNode->rightChild);
		}
	}
}
int main() {
	TreeNode<char>*a = new TreeNode<char>('A'), *b = new TreeNode<char>('B'),
		*c = new TreeNode<char>('C'), *d = new TreeNode<char>('D'),
		*e = new TreeNode<char>('E');//����������
	Tree<char> tree;//					   a
	tree.Insert(a);//				 b             c
	tree.Insert(b, 'l', a);//			d       e
	tree.Insert(c, 'r', a);
	tree.Insert(d, 'r', b);
	tree.Insert(e, 'l', c);
	tree.CountNode();//ʵ�ʣ����������ʱ�临�Ӷ�O��n��
	cout << tree.Count()<<endl;
	return 0;
}