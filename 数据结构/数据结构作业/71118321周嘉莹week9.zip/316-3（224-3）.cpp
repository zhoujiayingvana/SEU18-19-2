#include<iostream>
#include<time.h>
#include<math.h>
#include<time.h>
clock_t time1, time2;
#define arrayNum (int)1e5
#define Max1 1e6
#define Max2 1e5
using namespace std;
class Sets {
private:
	int *parent;
	int *count;
	int n;//Ԫ��
public:
	Sets(int numberOfElements);
	void Insert(int p,int i);
	int SimpleFind(int i);
	void SimpleUnion(int i, int j);
	void WeightUnion(int i, int j);
	int CollapsingFind(int i);
};


Sets::Sets(int numberOfElements) {
	if (numberOfElements < 2)throw"Must have at least 2 elements";
	n = numberOfElements;
	parent = new int[n];
	count = new int[n];
	fill(parent,parent + n, -1);//��ʼ��Ϊ-1
	fill(count, count + n, -1);
}

void Sets::Insert(int p,int i) {//���ڵ�p������ڵ�i,���輯���е�Ԫ��Ϊ��Ȼ��0-n-1���±꼴Ϊ����Ԫ��
	parent[i] = p;
	count[p]--;//���ڵ��count���¼�ڵ����
}
int Sets::SimpleFind(int i) {
	while (parent[i] >= 0) i = parent[i];
	return i;
}

void Sets::SimpleUnion(int i, int j) {
	i = SimpleFind(i);
	j = SimpleFind(j);//�ҵ��������ϵĸ��ڵ�
	if (i != j) {
		parent[i] = j;//����һ����ת��Ϊ�ڶ�����������
	}
}

void Sets::WeightUnion(int i, int j) {
	i = SimpleFind(i); 
	j = SimpleFind(j);
	if (i != j) {
		parent[i] = -count[i];
		parent[j] = -count[j];
		int temp = parent[i] + parent[j];
		if (parent[i] > parent[j]) {//i�ӵ�j�ϳ�Ϊj������
			parent[i] = j;
			parent[j] = -1;
			count[j] = temp;
		}
		else {//j�ӵ�i��
			parent[j] = i;
			parent[i] = -1;
			count[i] = temp;
		}
	}
}

int Sets::CollapsingFind(int i) {
	int r;
	for (r = i; parent[r] >= 0; r = parent[r]);//�ҵ���
		while(i!=r){
			int s = parent[i];
			parent[i] = r;
			i = s;
	}
		return r;
}
int main() {
	srand(unsigned(time(0)));
	int a[arrayNum] = { 0 };
	Sets sets1(arrayNum);
	int i;
	time1 = clock();
	for (i = 0; i < Max1; i++) {
		int p = rand() % arrayNum;
		sets1.SimpleFind(p);
	}
	time2 = clock();
	cout << "SimpleFime time is " << time2 - time1 << endl;
	time1 = clock();
	for (i = 0; i < Max1; i++) {
		int p = rand() % arrayNum;
		sets1.CollapsingFind(p);
	}
	time2 = clock();
	cout << "CollapsingFind time is " << time2 - time1 << endl;
	time1 = clock();
	for (i = 0; i < Max2; i++) {
		int p = rand() % arrayNum;
		int q = rand() % arrayNum;
		sets1.SimpleUnion(p, q);
	}
	time2 = clock();
	cout << "SimpleUnion time is " << time2 - time1 << endl;
	Sets sets2(arrayNum);
	time1 = clock();
	for (i = 0; i < Max2; i++) {
		int p = rand() % arrayNum;
		int q = rand() % arrayNum;
		sets2.WeightUnion(p, q);
	}
	time2 = clock();
	cout << "WeightUnion time is " << time2 - time1 << endl;
}