#include<iostream>
using namespace std;
template<class T> class Tree;
template<class T> class InorderIterator;//�������������
template <class T>
class Stack
{
private:
	T*stack;//�洢ջԪ�ص�����
	int top, capacity;
public:
	Stack(int stackCapacity = 10);
	bool IsEmpty();
	T& Top();//����ջ��Ԫ��
	void Push(const T& item);//��ջ
	void Pop();//ɾ��ջ��Ԫ��
	~Stack() { delete[]stack; }
};
template<class T>
Stack<T>::Stack(int stackCpacity = 20) :capacity(stackCpacity)//���캯��
{
	if (capacity < 1) throw"stack capackty must be > 0";
	stack = new T[capacity];
	top = -1;
}
template<class T>
inline bool Stack<T>::IsEmpty()
{
	return top == -1;
}
template<class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty())throw"Stack is empty";
	return stack[top];
}
template<class T>
void Stack<T>::Push(const T&x)
{
	stack[++top] = x;
}
template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())throw"Stack is empty. Cannot delete.";
	/*if (top != 0) {
	if (stack[top - 1]->leftChild == stack[top]) {
	stack[top - 1]->leftChild = 0;
	}
	else stack[top - 1]->rightChild = 0;
	top--;
	}
	else top--;*/
	stack[top--] = 0;
}


template<class T>
class TreeNode {//���ڵ�
	friend class tree;
public:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
	TreeNode(T d = 0, TreeNode<T>* l = 0, TreeNode<T>* r = 0)
	{
		data = d; leftChild = l; rightChild = r;
	}
	TreeNode& operator=(TreeNode *k) {
		this->data = k->data;
		this->leftChild = k->leftChild;
		this->rightChild = k->rightChild;
		return *this;
	}
};



template<class T>
class Tree {
	friend class TreeNode<T>;
	friend class InorderIterator<T>;//�������������
private:
	TreeNode<T>*root;
public:
	Tree(TreeNode<T> *r = 0) { root = r; }//���캯��
	bool IsEmpty() { return root == NULL; }
	T RootData() { return root->data; }

	void InsertLeft(TreeNode<T>*p, TreeNode<T>*x = 0);//��x�������һ��p�ڵ�
	void InsertRight(TreeNode<T>*p, TreeNode<T>*x = 0);//��x�������һ��p�ڵ�

	TreeNode<T>* Copy(TreeNode<T>*currentNode);
	Tree(const Tree<T>& c) { root = Copy(c.root); }//���ƹ��캯��

	void Delete(TreeNode<T>*currentNode);
	~Tree() { Delete(root); }//��������

	void Visit(TreeNode<T>*Node) { cout << Node->data << ends; }
	void Inorder();
};

template<class T>
TreeNode<T>* Tree<T>::Copy(TreeNode<T>*currentNode) {//���ƹ��캯���ݹ�ʵ��
	if (currentNode == NULL) return NULL;
	TreeNode<T>*temp = new TreeNode<T>(currentNode->data);
	temp->leftChild = Copy(currentNode->leftChild);
	temp->rightChild = Copy(currentNode->rightChild);
	return temp;
}

template<class T>
void Tree<T>::Delete(TreeNode<T>*currentNode) {//���������ݹ�ʵ��
	if (currentNode == NULL) return;
	Delete(currentNode->leftChild);
	Delete(currentNode->rightChild);
	if (currentNode) {
		delete currentNode;
		currentNode = 0;
	}
}

template<class T>
void Tree<T>::InsertLeft(TreeNode<T>*p, TreeNode<T>*x) {//��x�������ڵ�p
	if (root == 0)root = p;//����
	else if (x->leftChild) {
		TreeNode<T>*temp = x->leftChild;
		x->leftChild = p;
		p->leftChild = temp;
	}
	else x->leftChild = p;
}

template<class T>
void Tree<T>::InsertRight(TreeNode<T>*p, TreeNode<T>*x) {//��x�������ڵ�p
	if (root == 0)root = p;//����
	else if (x->rightChild) {
		TreeNode<T>*temp = x->rightChild;
		x->rightChild = p;
		p->rightChild = temp;
	}
	else x->rightChild = p;
}

template<class T>
void Tree<T>::Inorder() {//�������
	InorderIterator<T> p(root);
	T*temp = 0;
	while (temp = p.Next()) {
		cout << *temp << ends;
	}
	cout << endl;
}



template<class T>
class InorderIterator {//�����������������
	friend class Tree<T>;
private:
	TreeNode<T> *current;
	Stack<TreeNode<T>*>s;
public:
	InorderIterator(TreeNode<T>* startNode = 0) { //���캯��
		current = startNode;
	}
	T&operator *()const { return current->data; }
	T*operator->()const { return&current->data; }
	T* Next();//��һ��Ԫ��
	bool operator!=(const InorderIterator<T> right)const { return current->data != right.current->data; }
	bool operator==(const InorderIterator<T> right)const { return current->data == right.current->data; }
};

template <class T>
T* InorderIterator<T>::Next() {//��һ��Ԫ��
	while (current) {
		s.Push(current);
		current = current->leftChild;
	}
	if (s.IsEmpty()) {
		current = 0;
		return 0;
	}//��������
	current = s.Top();
	s.Pop();
	T&temp = current->data;
	current = current->rightChild;
	return &temp;
}




int main() {
	TreeNode<int>*a = new TreeNode<int>(1), *b = new TreeNode<int>(2),//���Ͷ�����
		*c = new TreeNode<int>(3), *d = new TreeNode<int>(4),
		*e = new TreeNode<int>(5);// ����������
//      								       (tree)
		Tree<int> tree;//						a1
		tree.InsertLeft(a, a);
		tree.InsertLeft(b, a);//		 b2             c3
		tree.InsertLeft(d, b);//	 d4       e5
		tree.InsertRight(e, b);
		tree.InsertRight(c, a);
		cout << "���������";
		tree.Inorder();
	return 0;
}