#include<iostream>
using namespace std;
class Table
{
private:
	int p[20];
public:
	Table()
	{
		memset(p, 0, sizeof(p));//��ʼ��
		cout << "��������Ԫ����0����:" << endl;
		for(int i=0;i<20;i++)
		{
			cin >> p[i];
			if (p[i] == 0) break;
		}
	}
	int GetP(int i) { return p[i]; }
	int Compire(Table & t);
};
int Table::Compire(Table & t)
{
	int i = -1;
	do { i++; } while (p[i] == t.GetP(i));
	if (i >= 20) return 0;
	if ((p[i+1] == 0) || (t.GetP(i+1) == 0))
	{
		if (p[i]) return 1;
		else return -1;
	}
	else return -99999;//����������
}
int main()
{
	Table A, B;
	cout << A.Compire(B);
}
