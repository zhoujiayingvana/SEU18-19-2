#include<iostream>
#include<algorithm>
using namespace std;
template<class T>
struct LinkNode {
	T data;
	LinkNode*link;
	LinkNode<T>() {

	}
	LinkNode<T>(T& d) {
		data = d;
		link = 0;
	}
};
template<class T>
class List {
private:
	LinkNode<T>*head;
	LinkNode<T>*last;
	int num;
public:
	List() {
		last = head=0;
		num = 0;
	}
	LinkNode<T>* Head() { return head; }
	LinkNode<T>* Last() { return last; }
	void add(T&d) {
		if (head == 0) {//��Ϊ��
			head = new LinkNode<T>(d);
			last = head;
			num++;
		}
		else {
			LinkNode<T>*p = new LinkNode<T>(d);
			last->link = p;
			last = p;
			num++;
		}
		
	}
	int Num() { return num; }

};

class Edge {
private:
	int u;
	int v;
	int w;//Ȩ��
public:
	Edge(int a=0, int b=0, int c=0) {
		u = a; v = b, w = c;
	}

	int W() { return w; }
	int U() { return u; }
	int V() { return v; }
	bool operator==(const Edge& t) {
		if (u == t.u&&v == t.v)return true;
		else return false;
	}
	Edge& operator=(int i) {
		this->u = 0;
		this->v = 0;
		this->w = 0;
		return *this;
	}
	Edge& operator=(Edge&t) {
		this->u = t.u;
		this->v = t.v;
		this->w = t.w;
		return *this;
	}
};
template<class T>
class Sets {//���鼯
private:
	int *parent;
	int *count;
	int n;//Ԫ�ظ���
	T*data;
public:
	Sets(int numberOfElements=20);
	void Insert(T i);
	int SimpleFind(T i);
	void WeightUnion(T i, T j);
	int CollapsingFind(T i);
	int FindScript(T i);//Ѱ��Ԫ���±�
};

template<class T>
Sets<T>::Sets<T>(int numberOfElements) {
	parent = new int[numberOfElements];
	count = new int[numberOfElements];
	data = new T[numberOfElements];
	n = 0;
	fill(parent, parent + n, -1);//��ʼ��Ϊ-1
	fill(count, count + n, -1);
	fill(data, data + n, -1);
}
template<class T>
int Sets<T>::FindScript(T i) {
	for (int k = 0; k < n; k++) {//�ҵ�Ԫ�ض�Ӧ�������±�
		if (data[k] == i)return k;
	}
	return -1;//û���ҵ�
}
template <class T>
void Sets<T>::Insert(T i) {//����ڵ�i,��Ϊ���׽��
	data[n] = i;
	parent[n] = -1;
	n++;
}
template<class T>
int Sets<T>::SimpleFind(T i) {
	int k = FindScript(i);
	while (parent[k] >= 0) k = parent[k];
	return k;
}
template<class T>
void Sets<T>::WeightUnion(T i, T j) {
	int a = SimpleFind(i);//���ڵ�Ǳ�Ϊa
	int b = SimpleFind(j);//���ڵ�Ǳ�Ϊb
	if (a != b) {//����Ԫ�ز���ͬһ������
		parent[a] = -count[a];
		parent[b] = -count[b];
		int temp = parent[a] + parent[b];
		if (parent[a] > parent[b]) {//a������a�ӵ�b�ϳ�Ϊb������,a�Ľڵ�����b�Ľڵ�
			parent[a] = b;
			parent[b] = -1;
			count[b] = temp;
		}
		else {//j�ӵ�i��
			parent[b] = a;
			parent[a] = -1;
			count[a] = temp;
		}
	}
}
template<class T>
int Sets<T>::CollapsingFind(T i) {
	int k = FindScript(i);
	int r;
	for (r = k; parent[r] >= 0; r = parent[r]);//�ҵ���
	while (k != r) {
		int s = parent[k];
		parent[k] = r;
		k = s;
	}
	return r;
}


template<class T>
class MinPQ {//С����
public:
	virtual~MinPQ() {};
	virtual bool IsEmpty() = 0;
	virtual  T&Top() = 0;
	virtual void Push(T &) = 0;
	virtual void Pop() = 0;
};
template<class T>
class MinHeap :public MinPQ<T> {
private:
	T*heap;//��ָ���ʾ����
	
	int capacity;
public:int heapsize;
	MinHeap(int theCapacity = 20);
	bool IsEmpty() { return heapsize == 0; }
	T&Top() { return heap[1]; }
	void Push(T&);
	void Pop();
	void ChangeSize(T*, int Old, int New);
	~MinHeap() {
		if (heap) {
			if (IsEmpty())delete heap;
			else delete[] heap;
		}
	}
	void print() {
		if (!IsEmpty()) {
			for (int i = 1; i <= heapsize; i++) { cout << heap[i].W() << ends; }
			cout << endl;
		}
	}
};
template<class T>
MinHeap<T>::MinHeap(int theCapacity) {
	if (theCapacity < 1)throw "Capacity must be >=1";
	capacity = theCapacity;
	heapsize = 0;
	heap = new T[capacity + 1];//heap[0]is not used
	memset(heap, 0, sizeof(heap));
}
template<class T>
void MinHeap<T>::ChangeSize(T*, int Old, int New) {
	if (New <= Old) throw"New capacity must be> the old capacity";
	T*temp = new T[New + 1];
	memset(temp, 0, sizeof(temp));
	for (int i = 0; i <= heapsize; i++) {
		temp[i] = heap[i];
	}
	delete[]heap;
	heap = temp;
}
template<class T>
void MinHeap<T>::Push(T& e) {
	if (heapsize == capacity) {
		ChangeSize(heap, capacity, 2 * capacity);
		capacity *= 2;
	}
	int currentNode = ++heapsize;
	while (currentNode != 1 && heap[currentNode / 2].W() > e.W()) {
		heap[currentNode] = heap[currentNode / 2];
		currentNode /= 2;
	}
	heap[currentNode] = e;
}
template<class T>
void MinHeap<T>::Pop() {
	if (IsEmpty())throw"Heap if empty.Cannot delete.";
	heap[1] = 0;
	T lastE = heap[heapsize--];
	int currentNode = 1;
	int child = 2;
	while (child <= heapsize) {
		if ((child<heapsize)&&(heap[child].W()>heap[child + 1].W()))child++;//�ҵ�ͬ������С������
		if (lastE.W() <= heap[child].W())break;//�������Ԫ�ص��ƶ�
		heap[currentNode] = heap[child];//��С��Ԫ������һ��
		currentNode = child;
		child *= 2;
	}
	heap[currentNode] = lastE;
}



class Graph {//ͼ
private:
	int n;//������
	int e;//����
	MinHeap<Edge> E;//ԭ�߼�����С����
	Sets<int> S;//����߰����Ķ��㣬�ò��鼯���涥��
public:
	Graph() { n = 0; }
	void InsertEdge(Edge& t);//��ͼ�в����t

	bool IsEmpty()const { return n == 0; }
	int NumberOfEdges()const { return e; }
	int NumberOfVertics()const { return n; }
	List<Edge>& KruskalSpanningTree();//��³˹������С������
};
void Graph::InsertEdge(Edge &t) {//��ͼ�в���ߣ�u��v��
	E.Push(t);
	e++;
	if (S.SimpleFind(t.U()) == -1) {
		S.Insert(t.U()), n++;
	}
	if (S.SimpleFind(t.V()) == -1) {
		S.Insert(t.V());
		n++;
	}
}
List<Edge>& Graph::KruskalSpanningTree() {
	List<Edge> l;//�����������ߵļ���
	while ((l.Num() < n - 1 )&& (!E.IsEmpty())) {
		Edge t = E.Top();
		E.Pop();
		if (S.CollapsingFind(t.U()) != S.CollapsingFind(t.V())){//�ж��Ƿ�ɻ�
			l.add(t);//���ɻ�
			S.WeightUnion(t.U(), t.V());//���Ѿ��ҵ��Ķ���ϲ�
		}
	}
	if (l.Num() < n - 1) cout << "û����С������" << endl;
	return l;
}
int main() {
	Edge a(0, 1, 28), b(1, 2, 16), c(2, 3, 12), d(3, 4, 22), e(4, 5, 25),
		f(5, 0, 10), g(1, 6, 14), h(4, 6, 24), i(3, 6, 18);
	Graph G;
	G.InsertEdge(a); G.InsertEdge(b); G.InsertEdge(c); G.InsertEdge(d);
	G.InsertEdge(e); G.InsertEdge(f); G.InsertEdge(g),G.InsertEdge(h); G.InsertEdge(i);
	List<Edge> k;
	k=G.KruskalSpanningTree();
	LinkNode<Edge>*p = k.Head();
	while (p) {
		cout << "(" << p->data.U() << "," << p->data.V() << "," << p->data.W() << ")" << endl;
		p=p->link;
	}
	return 0;
}
