#include<iostream>
#include<time.h>
#include<stdlib.h>
#define N 39
#define M 19
#define IBUG 0
#define JBUG 0
using namespace std;
int Count = 0;//记录步数
bool Full(int a[][M], int n, int m)//判断是否走完
{
	int i,j;
	for(i=0;i<n;i++)
	{
		for (j = 0; j < m; j++)
		{
			if (a[i][j] == 0)
				return 0;
		}
	}
	return 1;
}
bool fun(int a[][M], int n, int m, int ibug, int jbug)
{
	int k;//随机数
	int imove[8] = { -1,0,1,1,1,0,-1,-1 }, jmove[8] = { 1,1,1,0,-1,-1,-1,0 };
	a[ibug][jbug]++;//a[x][y]为1
	while (Count <= 50000)
	{
		do {
			k = rand() % 8;
		} while ((ibug+imove[k]>=n)||(ibug+imove[k]<0)||(jbug+jmove[k]>=m)||(jbug+jmove[k]<0));//碰墙
		ibug += imove[k];
		jbug += jmove[k];
		Count++;
		a[ibug][jbug]++;
		if (Full(a, n, m))
		{
			cout << "Count=" << Count << endl;
			int i, j;
			for (i = 0; i<n; i++)
			{
				for (j = 0; j < m; j++)
				{
					cout << a[i][j] << "	";
				}
				cout << endl;
			}
			Count = 0;
			return 1;
		}
	}
	Count = 0;//Count清零
	return 0;
}
int main()
{
	srand((unsigned)int(time(0)));
	int a[N][M] = { 0 };
	//memset(a, 0, sizeof(a));
	fun(a,N, M, IBUG, JBUG);
	return 0;
}