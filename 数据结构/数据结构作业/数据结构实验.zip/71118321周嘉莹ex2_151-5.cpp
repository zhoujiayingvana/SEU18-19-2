#include<iostream>
#include<math.h>
using namespace std;
class Polynomial;
//��ͷ����ѭ����������ϵ�������ÿռ�����
struct ChainNode{
	friend class Polynomial;
	int coef;
	int exp;
	ChainNode *link;
public:
	ChainNode(int c=0, int e=0, ChainNode *l=0) {
		coef = c; exp = e; link = l;
	}
	ChainNode* setChainNode(int c = 0, int e = 0, ChainNode *l = 0) {
		coef = c; exp = e; link = l;
		return this;
	}
};
class Polynomial {
private:
	ChainNode *head;
	ChainNode *last;
	static ChainNode *av;
	int n;
public:
	Polynomial() { head = last = GetNode(-1, -1, 0); last->link = head; n = 0; }
	ChainNode* GetNode(int c,int e,ChainNode* l);//���һ���ڵ�
	friend istream& operator >> (istream& is, Polynomial& x);//�������ʽ
	friend ostream& operator <<(ostream& os, Polynomial& x);//�������ʽ
	Polynomial(Polynomial& a);//���ƹ��캯��
	Polynomial& operator =( Polynomial& a);//��ֵ=
	~Polynomial();//��������
	Polynomial operator +(const Polynomial& b)const;//�ӷ�
	Polynomial operator -(const Polynomial& b)const;//����
	Polynomial operator *( Polynomial& b);//�˷�
	float Evaluate(float x)const;//��x���������ʽ
	friend void OrderInsertMerge(Polynomial &L, ChainNode* e);
};
ChainNode *Polynomial::av = 0;
ChainNode* Polynomial::GetNode(int c=0, int e=0, ChainNode* l=0) {//���һ���ڵ�
	ChainNode *x;
	if (av) { x = av; av = av->link; }
	else x = new ChainNode;
	return x->setChainNode(c,e,l);
}
istream& operator >> (istream& is, Polynomial& x) {//�������ʽ
	cout << "�Ա�׼��ʽ�������ʽ,��ϵ��Ϊ0����" << endl << "����������";
	int c=1, e=1;
	is >> x.n;
	while (1) {
		cout << "�������";
		is >> c;
		if (c) {
			is >> e;
			x.last->link=x.GetNode(c, e, x.head);
			x.last = x.last->link;
		}
		else break;
	}
	return is;
}
ostream& operator <<(ostream& os, Polynomial& x) {//�������ʽ
	ChainNode *p = x.head->link;
	os << x.n << ends;
	while (p != x.head) {
		os << p->coef << ends << p->exp << ends;
		p = p->link;
	}
	return os;
}
Polynomial::Polynomial(Polynomial& a) {//���ƹ��캯��
	head = last = GetNode(-1, -1, 0); last->link = head; n = 0;
	ChainNode *p = a.head->link;
	while (p != a.head) {
		last->link = GetNode(p->coef, p->exp, head);
		last = last->link;
		p = p->link;
		n++;
	}
}
Polynomial& Polynomial::operator =(Polynomial& a) { //��ֵ=
	this->~Polynomial();
	head = last = GetNode(-1, -1, 0); last->link = head; n = 0;
	ChainNode *p = a.head->link;
	while (p != a.head) {
		last->link = GetNode(p->coef, p->exp, head);
		last = last->link;
		p = p->link;
		n++;
	}
	return *this;
}
Polynomial::~Polynomial() {//��������
	last->link = av;
	av = head;
}
Polynomial Polynomial::operator +(const Polynomial& b)const {//�ӷ�
	Polynomial c;
	ChainNode *ai = head->link, *bi = b.head->link;
	while (1) {
		if (ai->exp == bi->exp) {
			if (ai->exp == -1) return c;
			int sum = ai->coef + bi->coef;
			if (sum) {
				c.last->link = c.GetNode(sum, ai->exp, c.head);
				c.last = c.last->link;
				c.n++;
			}
			ai = ai->link; bi = bi->link;
		}
		else if (ai->exp < bi->exp) {
			c.last->link = c.GetNode(bi->coef, bi->exp, c.head);
			c.last = c.last->link;
			c.n++;
		}
		else {
			c.last->link = c.GetNode(ai->coef, ai->exp, c.head);
			c.last = c.last->link;
			c.n++;
		}
	}
}
Polynomial Polynomial::operator -(const Polynomial& b)const{//����
	Polynomial c;
	ChainNode *ai = head->link, *bi = b.head->link;
	while (1) {
		if (ai->exp == bi->exp) {
			if (ai->exp == -1) return c;
			int sum = ai->coef - bi->coef;
			if (sum) {
				c.last->link = c.GetNode(sum, ai->exp, c.head);
				c.last = c.last->link;
				c.n++;
			}
			ai = ai->link; bi = bi->link;
		}
		else if (ai->exp < bi->exp) {
			c.last->link = c.GetNode(-bi->coef, bi->exp, c.head);
			c.last = c.last->link;
			c.n++;
		}
		else {
			c.last->link = c.GetNode(ai->coef, ai->exp, c.head);
			c.last = c.last->link;
			c.n++;
		}
	}
}
void OrderInsertMerge(Polynomial &L, ChainNode* e) {//��e���뵽��ȷ��λ�ã�Ĭ�Ͻ���
	if (L.head == L.last) {
		L.last->link = L.GetNode(e->coef, e->exp, L.head);
		L.last = L.last->link;
		L.n++;
	}
	else {
		ChainNode *p = L.head, *q = L.head->link;
		while (q->exp > e->exp) {
			p = p->link;
			q = q->link;
			//if (q == L.head) { p->link = e; e->link = L.head; L.n++; return; }
		}
			if (q->exp == e->exp) { q->coef += e->coef; delete[]e; e = q; }
			else {
				e->link = q;
				p->link = e;
			}
			L.n++;
			if (q == L.head) { p->link = e; e->link = L.head; }
		}
}
Polynomial Polynomial::operator *( Polynomial& b) {//�˷�

//����ʽ�ӷ�:Pa = Pa*Pb,������������ʽ�Ľ�㹹�ɡ��Ͷ���ʽ��
	ChainNode * qa = 0, *qb = 0;
	Polynomial Pc;//��ʱ����ʽ����
	qa =head->link;
	qb = b.head->link;//qa��qb�ֱ�ָ��Pa��Pb��ͷ���
	if (n != 0 && b.n != 0)
	{
		while (qa!=head)
		{
			while (qb!=b.head)
			{
				ChainNode *c = GetNode();
				c->coef = qa->coef*qb->coef;
				c->exp = qa->exp + qb->exp;
				OrderInsertMerge(Pc, c);
				qb = qb->link;
			}
			qa = qa->link;
			qb = b.head->link;
		}
	}
	else if (n == 0)
	{
		//do nothing,because The polynoimal is 0

	}
	else if (b.n == 0)
	{
		*this=b;//��Pb��ֵ��Pa������ҲΪ0
	}
	return Pc;
}
float Polynomial::Evaluate(float x)const {//��x���������ʽ
	ChainNode *p = head->link;
	float t = 0;
	while (p != head) {
		t += p->coef*pow(x, p->exp);
		p = p->link;
	}
	return t;
}
int main() {
	Polynomial A;
	cin >> A;
	Polynomial B,C,D;
	B = A;
	D = A + B;
	cout << D << endl;
	D = D - A;
	cout << D << endl;
	cout << A<<endl;
	cout << B << endl;
	cout << A.Evaluate(2)<<endl;
	C = A*B;
	cout << C << endl;
	return 0;
}
