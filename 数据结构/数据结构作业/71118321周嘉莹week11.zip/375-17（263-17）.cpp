#include<iostream>
#define MAX 999
using namespace std;
class Stack
{
private:
	T*stack;//�洢ջԪ�ص�����
	int top, capacity;
public:
	Stack(int stackCapacity = 10);
	bool IsEmpty();
	T& Top();//����ջ��Ԫ��
	void Push(const T& item);//��ջ
	void Pop();//ɾ��ջ��Ԫ��
	Stack<T>& DivideStack();//��һ��ջ��Ϊ2��ջ��������һ��ջ;
	void CombineStack(Stack&);//������ջ�ϲ�Ϊһ��ջ������ԭջ
	void ChangeSizeID(T*, int, int);//�ı�ջ��С
	void Print();
	void Delete();
};
template<class T>
Stack<T>::Stack(int stackCpacity) :capacity(stackCpacity)//���캯��
{
	if (capacity < 1) throw"stack capackty must be > 0";
	stack = new T[capacity];
	top = -1;
}
template<class T>
inline bool Stack<T>::IsEmpty()
{
	return top == -1;
}
template<class T>
inline T& Stack<T>::Top()
{
	if (IsEmpty())throw"Stack is empty";
	return stack[top];
}
template<class T>
void Stack<T>::ChangeSizeID(T*stack, int a, int b)
{
	if (a < b)
	{
		T*t = new T[b];
		for (int i = 0; i < a; i++) t[i] = stack[i];
		delete[]stack;
		stack = t;
	}
}
template<class T>
void Stack<T>::Push(const T&x)
{
	if (top == capacity - 1)
	{
		ChangeSizeID(stack, capacity, 2 * capacity);
		capacity *= 2;
	}
	stack[++top] = x;
}
template<class T>
void Stack<T>::Pop()
{
	if (IsEmpty())throw"Stack is empty. Cannot delete.";
	stack[top--] = 0;
}
template<class T>
Stack<T>& Stack<T>::DivideStack()
{
	Stack<T> t;
	if (!IsEmpty())
	{
		if (top == 0) throw"Stack cannot divide.";
		else {
			int i;
			for (i = (top + 1) / 2; i <= top; i++)
			{
				t.Push(stack[i]);

			}
			int p = top;
			for (i = (p + 1) / 2; i <= p; i++)
				Pop();
			return t;
		}
	}
}
template<class T>
void Stack<T>::CombineStack(Stack<T>& b)
{
	while (!b.IsEmpty())
	{
		Push(b.Top());
		b.Pop();
	}
}
template<class T>
void Stack<T>::Print()
{
	if (!IsEmpty())
	{
		for (int i = 0; i <= top; i++)
			cout << stack[i] << ends;
	}
	cout << endl;
}
template<class T>
void Stack<T>::Delete() {
	if (stack)
		delete[]stack;
}
class Edge {//����ͼ�ı�
	friend class MatrixWDigraph;
private:
	int weight;
	int u;
	int v;
public:
	Edge(int a = 0, int b = 0, int c = 0) {
		u = a;
		v = b;
		weight = c;
	}
	int Weight() { return weight; }
	int U() { return u; }
	int V() { return v; }
};
class MatrixWDigraph {
private:
	int **length;//�ڽӾ���
	int **a;//ÿ�Զ������̾�������
	int *dist;
	int **key;//����������·��
	int numOfVertix;//�������
	int numOfEdge;//�߸���
	Edge *EdgeCollection;//�߼�
public:
	MatrixWDigraph(int n);
	void AddEdge(Edge e);
	void AllLengths(int n);
	void OutputPath(int i, int j);
	~MatrixWDigraph();
};
MatrixWDigraph::MatrixWDigraph(int n) {
	numOfVertix = n;
	numOfEdge = 0;
	length = new int*[n];
	key = new int*[n];
	a = new int*[n];
	for (int i = 0; i < n; i++) {
		length[i] = new int[n];
		key[i] = new int[n];
		a[i] = new int[n];
		fill(length[i], length[i] + n, MAX);
		fill(key[i], key[i] + n, -1);
		fill(a[i], a[i] + n, MAX);
	}//��lengthָ�봴����̬����
	EdgeCollection = new Edge[10];
}
void MatrixWDigraph::AddEdge(Edge e) {
	EdgeCollection[numOfEdge] = e;//?????????????f��������
	numOfEdge++;
	length[e.U()][e.V()] = e.Weight();
	length[e.U()][e.U()] = 0;
	length[e.V()][e.V()] = 0;
}
MatrixWDigraph::~MatrixWDigraph() {
	if (length) {
		for (int i = 0; i < numOfEdge; i++)
			delete[]length[i];
		delete[]length;
	}

	if (key) {
		for (int k = 0; k < numOfEdge; k++)
			delete[]key[k];
		delete[]key;
	}
	if (a) {
		for (int j = 0; j < numOfEdge; j++)
			delete[]a[j];
		delete[]a;
	}
	if (dist) delete[]dist;
}
void MatrixWDigraph::AllLengths(int n) {
	int i, j, k;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			a[i][j] = length[i][j];
		}
	}//��ʼ��a[][]
	for (k = 0; k < n; k++) {
		for (i = 0; i < n; i++) {
			for (j = 0; j < n; j++) {
				if (a[i][k] + a[k][j] < a[i][j]) {
					a[i][j] = a[i][k] + a[k][j];
					key[i][j] = k;
				}
			}
		}
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i != j) {
				cout << i << "->" << j << "��"<<i;
				OutputPath(i, j);
				cout << "      The length of path is " << a[i][j];
				cout << endl;
			}
		}
	}
}
void MatrixWDigraph::OutputPath(int i, int j)
{// does not output first vertex (i) on path
	if (i == j||a[i][j] == MAX) {
		cout << "û��·��";
		return;
	}
	if (key[i][j] == -1) // no intermediate vertices on path
		cout <<" "<< j;
	else {// kay[i][j] is an intermediate vertex on the path
		OutputPath(i, key[i][j]);
		OutputPath(key[i][j], j);
	}
}
int main() {
	MatrixWDigraph M(3);
	Edge a(0, 1, 4), b(1, 2, 2), c(0, 2, 11), d(1, 0, 6), e(2, 0, 3);
	M.AddEdge(a);//                            __(6)__        ������ͼ6.32��ͬ
	M.AddEdge(b);//                          �L       �v      
	M.AddEdge(c);//                         0����(4)����1
	M.AddEdge(d);//                       �J �v       �u
	M.AddEdge(e);//                  (3)�u (11)�K   �u(2)
	M.AllLengths(3);//               �u ________  2
	return 0;//
}