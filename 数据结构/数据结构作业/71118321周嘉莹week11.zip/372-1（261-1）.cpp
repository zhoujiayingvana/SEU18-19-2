#include<iostream>
using namespace std;
class Tree;
class TreeNode {
	friend class Tree;
private:
	int name;
	int weight;
	TreeNode*leftChild;
	TreeNode*rightChild;
	TreeNode*parent;
public:
	TreeNode(int n,int w=0) {
		name = n;
		weight = w;
		leftChild = 0;
		rightChild = 0;
		parent = 0;
	}
	~TreeNode() {
		if (this) delete this;
	}
};
class Tree {
private:
	TreeNode*root;
public:
	Tree(TreeNode*p) {
		root =p;
	}
	void insertLeft(TreeNode*p, TreeNode*child);
	void insertRight(TreeNode*p,TreeNode*child);
	int shortestPath(TreeNode*t);
};
void Tree::insertLeft(TreeNode*p, TreeNode*child) {
	p->leftChild = child;
	child->parent = p;
}
void Tree::insertRight(TreeNode*p, TreeNode*child) {
	p->rightChild = child;
	child->parent = p;
}
int Tree::shortestPath(TreeNode*t) {
	int length = 0;
	TreeNode*x = t;
	while(t!=root){
		length += t->weight;
		t = t->parent;
	}
	return length;
}
int main() {
	TreeNode*a = new TreeNode(0), *b = new TreeNode(1, 1), *c = new TreeNode(2, 2),
		*d = new TreeNode(3, 3), *e = new TreeNode(4, 4), *f = new TreeNode(5, 5),
		*g = new TreeNode(6, 6);
	Tree tree(a);
	tree.insertLeft(a, b);//                              a(0)
	tree.insertRight(a, c);//                    b(1)               c(2)
	tree.insertLeft(b, d);//                d(3)     e(4)       f(5)     g(6)
	tree.insertRight(b, e);//
	tree.insertLeft(c, f);//
	tree.insertRight(c, g);//
	cout << "a->b:" << tree.shortestPath(b)<<endl;
	cout << "a->c:" << tree.shortestPath(c) << endl;
	cout << "a->d:" << tree.shortestPath(d) << endl;
	cout << "a->e:" << tree.shortestPath(e) << endl;
	cout << "a->f:" << tree.shortestPath(f) << endl;
	cout << "a->g:" << tree.shortestPath(g) << endl;

	return 0;
}