#include<iostream>
using namespace std;
template<class T> class ThreadedTree;
template<class T>
class TreeNode {
	friend class ThreadedTree<T>;
private:
	T data;
	TreeNode<T> *leftChild;
	TreeNode<T> *rightChild;
	bool leftThread;
	bool rightThread;
public:
	TreeNode(T d) { data = d; leftChild = rightChild = 0; leftThread = rightThread = true; }
};
template<class T>
class ThreadedTree {
private:
	TreeNode<T>*root;
	TreeNode<T>* pre;//ʼ��ָ��ǰһ���ڵ�
public:
	ThreadedTree() {
		
		root = new TreeNode<T>(-1);
		root->leftChild = 0;
		root->rightChild = root;
		root->leftThread=true;
		root->rightThread = false;
		pre = root;
	}
	void InsertRight(TreeNode<T>*s, TreeNode<T>*r);//����������
	void InsertLeft(TreeNode<T>*s, TreeNode<T>*r);//����������
	void PreorderThread() {
		if (root->leftChild) {
			PreorderThread(root->leftChild);
			pre->rightChild = root;
		}
		else cout << "��Ϊ��";
	}
	void PreorderThread(TreeNode<T>*t);//������ǰ��������
	//void PreThreading() { PreThreading(root->leftChild); }//����root������
	//void PreThreading(TreeNode<T>*currentNode);
	TreeNode<T>* Root() { return root; }
	void Preorder();//�������
};
template<class T>
void ThreadedTree<T>::InsertRight(TreeNode<T>*s, TreeNode<T>*r) {//��r���뵽s��������
	if (s->rightChild) {
		r->rightChild = s->rightChild;
		s->rightChild = r;
		r->rightThread = false;
		s->leftThread = false;
	
	}
	else {
		s->rightChild = r;
		s->rightThread = false;
	}
}
template<class T>
void ThreadedTree<T>::InsertLeft(TreeNode<T>*s, TreeNode<T>*r) {
	if (s->leftChild) {
		r->leftChild = s->leftChild;
		s->leftChild = r;
		r->leftThread = false;
		s->leftThread = false;
	}
	else {
		s->leftChild = r;
		s->leftThread = false;
	}
}
template<class T>
void ThreadedTree<T>::PreorderThread(TreeNode<T>*t) {
	if (t) {
		if (!t->leftChild) {//û������
			t->leftThread = true;
			t->leftChild = pre;
		}
		if (pre!=0&&(!pre->rightChild)) {//ǰ��û���Һ���
			pre->rightThread = true;
			pre->rightChild = t;//ǰ������ָ��ָ����
		}
		pre =t;
		if (t->leftThread==false)//��������
			PreorderThread(t->leftChild);
		if (t->rightThread==false)
			PreorderThread(t->rightChild);
	}
}
//template<class T>
/*void ThreadedTree<T>::PreThreading(TreeNode<T>*currentNode) {
	if (!currentNode->rightChild) {//������Ϊ��
		currentNode->rightChild = root;
		root->rightChild = currentNode;
		root->leftThread = false;
		return;
	}
}*/
template<class T>
void ThreadedTree<T>::Preorder() {
	if (!root->leftChild) {
		cout << "��Ϊ��" << endl;
		return;
	}
	TreeNode<T>*currentNode=root->leftChild;
	while (currentNode!=root) {
		 while (!currentNode->leftThread){//��������Ϊ��
			cout << currentNode->data << ends;
			currentNode = currentNode->leftChild;
		}
		cout << currentNode->data << ends;
		currentNode = currentNode->rightChild;
	}
}
int main() {
	TreeNode<int>a(1), b(2), c(3), d(4), e(5);
	ThreadedTree<int> A; //                  ��
	A.InsertLeft(A.Root(), &a);//			root
	A.InsertLeft(&a, &b);//             a
	A.InsertRight(&a, &c);//       b        c
	A.InsertLeft(&b, &d);//      d   e
	A.InsertRight(&b, &e);
	A.PreorderThread();
	//A.PreThreading();
	A.Preorder();
	return 0;
}