#include<iostream>
using namespace std;
template<class T>
class MinPQ {
public:
	virtual~MinPQ() {};
	virtual bool IsEmpty()=0;
	virtual const T&Top()const = 0;
	virtual void Push(T &) = 0;
	virtual void Pop() = 0;
};
template<class T>
class MinHeap:public MinPQ<T> {
private:
	T*heap;//��ָ���ʾ����
	int heapsize;
	int capacity;
public:
	MinHeap(int theCapacity=10);
	bool IsEmpty() { return heapsize == 0; }
	const T&Top()const { return heap[heapsize]; }
	void Push(T&);
	void Pop();
	void ChangeSize(T*, int Old, int New);
	~MinHeap() {
		if (heap) {
			if (IsEmpty())delete heap;
			else delete[] heap;
		}
	}
	void print() {
		if (!IsEmpty()) {
			for (int i = 1; i <= heapsize; i++) { cout << heap[i]<<ends; }
			cout << endl;
		}
	}
};
template<class T>
MinHeap<T>::MinHeap(int theCapacity) {
	if (theCapacity < 1)throw "Capacity must be >=1";
	capacity = theCapacity;
	heapsize = 0;
	heap = new T[capacity + 1];//heap[0]is not used
	memset(heap, 0, sizeof(heap));
}
template<class T>
void MinHeap<T>::ChangeSize(T*, int Old, int New) {
	if (New <= Old) throw"New capacity must be> the old capacity";
	T*temp = new T[New + 1];
	memset(temp, 0, sizeof(temp));
	for (int i = 0; i <= heapsize; i++) {
		temp[i] = heap[i];
	}
	delete[]heap;
	heap = temp;
}
template<class T>
void MinHeap<T>::Push(T& e) {
	if (heapsize == capacity) {
		ChangeSize(heap, capacity, 2 * capacity);
		capacity *= 2;
	}
	int currentNode = ++heapsize;
	while (currentNode != 1 && heap[currentNode / 2] > e) {
		heap[currentNode] = heap[currentNode / 2];
		currentNode /= 2;
	}
	heap[currentNode] = e;
}
template<class T>
void MinHeap<T>::Pop() {
	if (IsEmpty())throw"Heap if empty.Cannot delete.";
	heap[1] = 0;
	T lastE = heap[heapsize--];
	int currentNode = 1;
	int child = 2;
	while (child <= heapsize) {
		if (child<heapsize&&heap[child]>heap[child + 1])child++;//�ҵ�ͬ������С������
		if (lastE <= heap[child])break;//�������Ԫ�ص��ƶ�
		heap[currentNode] = heap[child];//��С��Ԫ������һ��
		currentNode = child;
		child *= 2;
	}
	heap[currentNode] = lastE;
}
int main() {
	MinHeap<int> M;
	int k = 20;
	for (int i = 1; i <= 5; i++)M.Push(i);
	M.Push(k);
	M.print();
	M.Pop();
	M.print();
	return 0;
}